export default {
    // region: '',
    // IdentityPoolId: '',
    UserPoolId: 'us-east-2_SF2DCPO5Y',
    ClientId: '617jkna9pqeg8rmgtg9uv4e6j4',
  }
  